package com.splitwise.component.generator

class GeneratorException(message: String) : RuntimeException(message)
