package com.splitwise.component.ui

import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.DialogWrapper
import java.awt.BorderLayout
import javax.swing.Box
import javax.swing.BoxLayout
import javax.swing.JCheckBox
import javax.swing.JComponent
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.JTextField

class CreateComponentDialog(project: Project) : DialogWrapper(project) {
    private val nameField = JTextField()
    private val blockCheckBox = JCheckBox("This component is a block")

    val componentName: String
        get() = nameField.text

    val isBlockComponent: Boolean
        get() = blockCheckBox.isSelected

    init {
        title = "Create Component"
        init()
    }

    override fun createCenterPanel(): JComponent {
        val panel = JPanel()
        panel.layout = BoxLayout(panel, BoxLayout.Y_AXIS)

        val namePanel = JPanel(BorderLayout(8, 8))
        namePanel.add(JLabel("Component name:"), BorderLayout.WEST)
        namePanel.add(nameField, BorderLayout.CENTER)

        panel.add(namePanel)
        panel.add(Box.createVerticalStrut(8))
        panel.add(blockCheckBox)

        return panel
    }
}
