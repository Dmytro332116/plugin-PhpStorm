rootProject.name = "component-generator"
